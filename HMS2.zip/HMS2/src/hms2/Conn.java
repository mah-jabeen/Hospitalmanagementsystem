
package hms2;

import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    Conn(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql:///hms","root","CS123+");
            s=c.createStatement();
        }
        catch(Exception e){ 
            e.printStackTrace();
        }  
    }  
}  
