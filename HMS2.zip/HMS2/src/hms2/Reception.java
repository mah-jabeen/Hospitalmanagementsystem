
package hms2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Reception extends JFrame implements ActionListener{
    JButton newCustomer,update,searchRoom,department,logout,roomstatus,checkout,rooms,managerInfo,allEmployee,customers;
    
    Reception(){
        
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        
        newCustomer=new JButton("New Customer");
        newCustomer.setBackground(Color.BLUE);
        newCustomer.setForeground(Color.WHITE);
        newCustomer.setBounds(10,30,200,30);
        newCustomer.addActionListener(this);
        add(newCustomer);
        
        rooms=new JButton("Rooms");
        rooms.setBackground(Color.BLUE);
        rooms.setForeground(Color.WHITE);
        rooms.setBounds(10,70,200,30);
        rooms.addActionListener(this);
        add(rooms);
        
        department=new JButton("Department");
        department.setBackground(Color.BLUE);
        department.setForeground(Color.WHITE);
        department.setBounds(10,110,200,30);
        department.addActionListener(this);
        add(department);
        
        allEmployee=new JButton("All Employees");
        allEmployee.setBackground(Color.BLUE);
        allEmployee.setForeground(Color.WHITE);
        allEmployee.setBounds(10,150,200,30);
        allEmployee.addActionListener(this);
        add(allEmployee);
        
        customers=new JButton("Customer Info");
        customers.setBackground(Color.BLUE);
        customers.setForeground(Color.WHITE);
        customers.setBounds(10,190,200,30);
        customers.addActionListener(this);
        add(customers);
        
        managerInfo=new JButton("Manager Info");
        managerInfo.setBackground(Color.BLUE);
        managerInfo.setForeground(Color.WHITE);
        managerInfo.setBounds(10,230,200,30);
        managerInfo.addActionListener(this);
        add(managerInfo);
        
        checkout=new JButton("Checkout");
        checkout.setBackground(Color.BLUE);
        checkout.setForeground(Color.WHITE);
        checkout.setBounds(10,270,200,30);
        checkout.addActionListener(this);
        add(checkout);
        
        update=new JButton("Update Status");
        update.setBackground(Color.BLUE);
        update.setForeground(Color.WHITE);
        update.setBounds(10,310,200,30);
        update.addActionListener(this);
        add(update);
        
        roomstatus=new JButton("Update Room Status");
        roomstatus.setBackground(Color.BLUE);
        roomstatus.setForeground(Color.WHITE);
        roomstatus.setBounds(10,350,200,30);
        roomstatus.addActionListener(this);
        add(roomstatus);
        
        searchRoom=new JButton("Search Room");
        searchRoom.setBackground(Color.BLUE);
        searchRoom.setForeground(Color.WHITE);
        searchRoom.setBounds(10,390,200,30);
        searchRoom.addActionListener(this);
        add(searchRoom);
        
        logout=new JButton("Logout");
        logout.setBackground(Color.BLUE);
        logout.setForeground(Color.WHITE);
        logout.setBounds(10,430,200,30);
        logout.addActionListener(this);
        add(logout);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/hk.jpg"));
        JLabel image=new JLabel(i1);
        image.setBounds(250,30,500,470);
        add(image);
        
        setBounds(350,200,800,570);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==newCustomer){
            setVisible(false);
            new AddCustomer();
        }else if(ae.getSource()==rooms){
            setVisible(false);
            new Room();
        }else if(ae.getSource()==department){
            setVisible(false);
            new Department();
        }else if(ae.getSource()==allEmployee){
            setVisible(false);
            new EmployeeInfo();
        }else if(ae.getSource()==managerInfo){
            setVisible(false);
            new ManagerInfo();
        }else if(ae.getSource()==customers){
            setVisible(false);
            new CustomerInfo();
        }else if(ae.getSource()==searchRoom){
            setVisible(false);
            new SearchRoom();
        }else if(ae.getSource()==checkout){
            setVisible(false);
            new Checkout();
        }else if(ae.getSource()==update){
            setVisible(false);
            new UpdateCheck();    
        }else if(ae.getSource()==roomstatus){
            setVisible(false);
            new UpdateRoom();
        }else if(ae.getSource()==logout){
            setVisible(false);
            System.exit(0);
        }
    }
    
    public static void main(String[] args){
        new Reception();
        
    }
}
